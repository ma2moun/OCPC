#include <iostream>
#include<fstream>
#include<cmath>

using namespace std;


int main() {

ifstream teams;
teams.open("teams.in");

int cases, N, S;
cases=0;
teams>>cases; //number of cases at the beginning
for (int i=1; i<=cases;i++) {
    teams>>N>>S;
    int max_teams=0;
    int team_created=0;
    //cout<<"\nN= "<<N<<", S="<<S<<endl;
    for (int j=0;j<N;j++){
        int ratings[N];
        teams>>ratings[N];
        //cout<<"Rating of "<<N<<" is "<<ratings[N]<<" "; //Testing
        for (int t=0;t<N;t++){ //Think of these lines
            for(int k=t+1;k<N;k++){ //Think of these lines
                if(ratings[t]-ratings[k]<=S){ //Think of these lines
                    max_teams++; //Think of these lines
                    if(max_teams==3){team_created++;}//Think of these lines
                }
            }
        //int tempMamber = ratings[t];
       }
    }
 cout<<team_created<<endl;
}
return 0;
}
