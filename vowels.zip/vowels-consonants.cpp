#include <iostream>
#include <fstream>
#include <string>
#include<vector>
#include <algorithm> //To use the find function

using namespace std;

// Function to print out the vector contents
void printVector(vector<char> b)
{
    for (int d = 0; d < b.size(); d++)
    {
        cout << b[d] << " ";
    }
}

int main() {

    int num;
    vector <char> input {'a','o','y','e','u','i'};
    ifstream vowels;
    vowels.open("vowels.in");

    vowels >> num; //number of chars in the line
    char arr[num]; //array to hold the string
    vector<char> vows, con; //two vectors, one for vowels and the other for consonants

    for (int i=0;i<num;i++){
        vowels>>arr[i]; //saving to array
    }

    for (int j=0; j<num;j++){
        auto check = find(input.begin(), input.end(), arr[j]) != input.end();  //it returns true or false
         if(check)
            {
                vows.push_back(arr[j]); //if Vowel
            }

         else
            {
                con.push_back(arr[j]); //If consonant
            }

        }

   vows.insert( vows.end(), con.begin(), con.end()); //concatenating two vectors (the vowels one and the cons one)

    printVector(vows);

    vowels.close();
    return 0;
}
