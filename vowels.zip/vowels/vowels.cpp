#include <iostream>
#include <fstream>
#include <string>
#include<vector>


using namespace std;


int main() {

int num;
char arr[6];
char  x;
char vow[6]={'a','o','y','e','u','i'};
ifstream vowels;
vowels.open("vowels.in");

vowels >> num;

for (int i=0;i<num;i++){
    vowels>>arr[i];
}
char tmp;
char newArr[num];

for (int j=0; j<num;j++){
    for(int k=0;k<6;k++)
        if(arr[j]==vow[k]){
                tmp = arr[j-1]; // Think of these lines
                arr[j-1]=arr[j]; // Think of these lines
                arr[j]=tmp; // Think of these lines
        }
}

for (int j=0; j<num;j++){
cout<<arr[j]<<' ';}

vowels.close();
return 0;
}
