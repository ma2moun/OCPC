#include <iostream>
#include <fstream>
#include <string>
#include<vector>


using namespace std;


int main() {
ifstream numbers;
numbers.open("numbers.in");

int cases, x, y;
numbers>>cases;



for (int i=1; i<=cases;i++)
    {
    numbers>>x>>y;
    if(x==y){cout<<0<<endl;}
    else if(y-x==1 || y-x==2 || y-x==3){
        cout<<1<<endl;
    }
    else if(y-x>3)
    {
        //4 (2 operations: 3,1 and 2 2)
        //5 (2 operations: 3,2)
        //6 (2 operations: 3,3)
        //7 (3 ops: 3,3,1 or 2,2,3)
        //8 (3 ops: 3,3,2)
        //9 (3 ops: 3,3,3)
        //10 (4 ops 3,3,3,1 or 2,2,3,3)
        // ANY CONCLUSIONS FROM THIS? RO SHOULD BE ANOTHER WAY?
    }

    }

return 0;
}
